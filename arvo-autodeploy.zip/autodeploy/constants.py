# optional constants
